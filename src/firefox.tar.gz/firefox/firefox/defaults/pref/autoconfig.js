// ESukmean's DOH config. jshlhs1@gmail.com으로 연락 주세요. (행아웃, 이메일 가능)
pref("general.config.filename", "esukmeans.cfg");
pref("general.config.obscure_value", 0);
